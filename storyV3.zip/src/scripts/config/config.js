const CONFIG = {
  // ... konfigurasi lainnya ...
  PUSH_MSG_VAPID_PUBLIC_KEY: 'BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk',
  PUSH_MSG_SUBSCRIBE_URL: 'https://story-api.dicoding.dev/v1/push-notif/subscribe',
  PUSH_MSG_UNSUBSCRIBE_URL: 'https://story-api.dicoding.dev/v1/push-notif/unsubscribe'
};

export default CONFIG;