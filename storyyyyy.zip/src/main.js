// src/main.js
import { initRouter } from './scripts/routes/index.js';
import './styles/styles.css';

function updateNavigation() {
  const authNav = document.getElementById('auth-nav');
  const token = localStorage.getItem('token');
  
  if (token) {
    authNav.innerHTML = `
      <a href="#/profile">Profile</a>
      <a href="#" id="logout">Logout</a>
    `;
    
    document.getElementById('logout').onclick = (e) => {
      e.preventDefault();
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      location.hash = '#/login';
      updateNavigation();
    };
  } else {
    authNav.innerHTML = `
      <a href="#/login">Login</a>
      <a href="#/register">Register</a>
    `;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  if (!document.startViewTransition) {
    initRouter();
    updateNavigation();
    return;
  }

  function updateTheDOMSomehow() {
    initRouter();
    updateNavigation();
  }

  document.startViewTransition(() => updateTheDOMSomehow());
});

window.addEventListener('hashchange', () => {
  if (!document.startViewTransition) {
    initRouter();
    return;
  }

  document.startViewTransition(() => initRouter());
});
